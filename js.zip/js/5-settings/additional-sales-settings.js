/* Additional Sales Settings - Настройки дополнительных продаж */
/* Версия: 1.672 */

// Additional sales settings page (formerly dish chain settings)
function viewDishChainSettings() {
  console.log('viewDishChainSettings called, dishChainSettings:', dishChainSettings);
  
  const wrapper = document.createElement('div');
  wrapper.className = 'page';

  const panel = document.createElement('section');
  panel.className = 'panel';
  panel.innerHTML = `
    <div class="panel-header">
      <button class="back-btn" id="dish-chain-back">‹</button>
      <h2 style="flex: 1; text-align: center; margin: 0;">Дополнительные продажи</h2>
      <div style="width: 40px;"></div>
    </div>
    
    <div class="settings-section">
      <p class="settings-description">Настройте автоматические предложения дополнительных блюд при добавлении в заказ</p>
      <button class="btn-primary" id="btn-create-custom-chain">
        <span style="font-size: 20px;">✨</span>
        <span>Создать связку</span>
      </button>
    </div>
    
    <div class="settings-section chain-settings-section">
      <!-- Стейки -->
      <div class="chain-settings-card" id="steak-chain-card">
        <div class="chain-settings-header">
          <div class="chain-settings-icon">🥩</div>
          <div class="chain-settings-info">
            <span class="chain-settings-title">Стейки</span>
            <span class="chain-settings-subtitle">Прожарка → Гарнир → Соус</span>
          </div>
          <div class="chain-settings-arrow" id="steak-arrow">›</div>
        </div>
        
        <div class="chain-settings-body" id="steak-chain-body">
          <div class="chain-toggle-item">
            <div class="chain-toggle-info">
              <span class="chain-toggle-label">Прожарка</span>
              <span class="chain-toggle-desc">Выбор степени прожарки</span>
            </div>
            <div class="settings-toggle active disabled" data-chain-toggle="cooking">
              <span class="toggle-lock">🔒</span>
            </div>
          </div>
          
          <div class="chain-toggle-item">
            <div class="chain-toggle-info">
              <span class="chain-toggle-label">Гарнир</span>
              <span class="chain-toggle-desc">Предложение гарнира к стейку</span>
            </div>
            <div class="settings-toggle ${dishChainSettings.steaks.garnishes ? 'active' : ''}" data-chain-toggle="garnishes"></div>
          </div>
          
          <div class="chain-toggle-item">
            <div class="chain-toggle-info">
              <span class="chain-toggle-label">Соус</span>
              <span class="chain-toggle-desc">Предложение соуса к стейку</span>
            </div>
            <div class="settings-toggle ${dishChainSettings.steaks.sauces ? 'active' : ''}" data-chain-toggle="sauces"></div>
          </div>
        </div>
      </div>
      
      <!-- Чай -->
      <div class="chain-settings-card" id="tea-chain-card">
        <div class="chain-settings-header">
          <div class="chain-settings-icon">🍵</div>
          <div class="chain-settings-info">
            <span class="chain-settings-title">Чай</span>
            <span class="chain-settings-subtitle">Мята, мёд, чабрец, сахар, лимон</span>
          </div>
          <div class="chain-settings-arrow" id="tea-arrow">›</div>
        </div>
        
        <div class="chain-settings-body" id="tea-chain-body">
          <div class="chain-toggle-item">
            <div class="chain-toggle-info">
              <span class="chain-toggle-label">Мята</span>
              <span class="chain-toggle-desc">Предложение мяты к чаю</span>
            </div>
            <div class="settings-toggle ${dishChainSettings.tea?.mint !== false ? 'active' : ''}" data-chain-toggle="tea-mint"></div>
          </div>
          
          <div class="chain-toggle-item">
            <div class="chain-toggle-info">
              <span class="chain-toggle-label">Мёд</span>
              <span class="chain-toggle-desc">Предложение мёда к чаю</span>
            </div>
            <div class="settings-toggle ${dishChainSettings.tea?.honey !== false ? 'active' : ''}" data-chain-toggle="tea-honey"></div>
          </div>
          
          <div class="chain-toggle-item">
            <div class="chain-toggle-info">
              <span class="chain-toggle-label">Чабрец</span>
              <span class="chain-toggle-desc">Предложение чабреца к чаю</span>
            </div>
            <div class="settings-toggle ${dishChainSettings.tea?.thyme !== false ? 'active' : ''}" data-chain-toggle="tea-thyme"></div>
          </div>
          
          <div class="chain-toggle-item">
            <div class="chain-toggle-info">
              <span class="chain-toggle-label">Сахар</span>
              <span class="chain-toggle-desc">Предложение сахара к чаю</span>
            </div>
            <div class="settings-toggle ${dishChainSettings.tea?.sugar !== false ? 'active' : ''}" data-chain-toggle="tea-sugar"></div>
          </div>
          
          <div class="chain-toggle-item">
            <div class="chain-toggle-info">
              <span class="chain-toggle-label">Лимон</span>
              <span class="chain-toggle-desc">Предложение лимона к чаю</span>
            </div>
            <div class="settings-toggle ${dishChainSettings.tea?.lemon !== false ? 'active' : ''}" data-chain-toggle="tea-lemon"></div>
          </div>
        </div>
      </div>
      
      <!-- Тар-тар -->
      <div class="chain-settings-card" id="tartare-chain-card">
        <div class="chain-settings-header">
          <div class="chain-settings-icon">🥩</div>
          <div class="chain-settings-info">
            <span class="chain-settings-title">Тар-тар</span>
            <span class="chain-settings-subtitle">Яйцо, крутоны, чипсы из бекона</span>
          </div>
          <div class="chain-settings-arrow" id="tartare-arrow">›</div>
        </div>
        
        <div class="chain-settings-body" id="tartare-chain-body">
          <div class="chain-toggle-item">
            <div class="chain-toggle-info">
              <span class="chain-toggle-label">Яйцо перепелиное</span>
              <span class="chain-toggle-desc">Предложение яйца к тар-тару</span>
            </div>
            <div class="settings-toggle ${dishChainSettings.tartare?.egg !== false ? 'active' : ''}" data-chain-toggle="tartare-egg"></div>
          </div>
          
          <div class="chain-toggle-item">
            <div class="chain-toggle-info">
              <span class="chain-toggle-label">Крутоны из багета</span>
              <span class="chain-toggle-desc">Предложение крутонов к тар-тару</span>
            </div>
            <div class="settings-toggle ${dishChainSettings.tartare?.croutons !== false ? 'active' : ''}" data-chain-toggle="tartare-croutons"></div>
          </div>
          
          <div class="chain-toggle-item">
            <div class="chain-toggle-info">
              <span class="chain-toggle-label">Чипсы из бекона</span>
              <span class="chain-toggle-desc">Предложение чипсов к тар-тару</span>
            </div>
            <div class="settings-toggle ${dishChainSettings.tartare?.bacon !== false ? 'active' : ''}" data-chain-toggle="tartare-bacon"></div>
          </div>
        </div>
      </div>
      
      <!-- Коктейли -->
      <div class="chain-settings-card" id="cocktail-chain-card">
        <div class="chain-settings-header">
          <div class="chain-settings-icon">🍹</div>
          <div class="chain-settings-info">
            <span class="chain-settings-title">Коктейли</span>
            <span class="chain-settings-subtitle">Предложение двойной порции</span>
          </div>
          <div class="chain-settings-arrow" id="cocktail-arrow">›</div>
        </div>
        
        <div class="chain-settings-body" id="cocktail-chain-body">
          <div class="chain-toggle-item">
            <div class="chain-toggle-info">
              <span class="chain-toggle-label">Двойная порция</span>
              <span class="chain-toggle-desc">Предложение двойной порции коктейля</span>
            </div>
            <div class="settings-toggle ${dishChainSettings.cocktails?.double !== false ? 'active' : ''}" data-chain-toggle="cocktail-double"></div>
          </div>
        </div>
      </div>
      
      <!-- Витело тонато -->
      <div class="chain-settings-card" id="vitello-chain-card">
        <div class="chain-settings-header">
          <div class="chain-settings-icon">🍖</div>
          <div class="chain-settings-info">
            <span class="chain-settings-title">Витело тонато</span>
            <span class="chain-settings-subtitle">Фоккача с розмарином</span>
          </div>
          <div class="chain-settings-arrow" id="vitello-arrow">›</div>
        </div>
        
        <div class="chain-settings-body" id="vitello-chain-body">
          <div class="chain-toggle-item">
            <div class="chain-toggle-info">
              <span class="chain-toggle-label">Фоккача</span>
              <span class="chain-toggle-desc">Предложение фоккачи к витело тонато</span>
            </div>
            <div class="settings-toggle ${dishChainSettings.vitello?.focaccia !== false ? 'active' : ''}" data-chain-toggle="vitello-focaccia"></div>
          </div>
        </div>
      </div>
      
      <!-- Пиво -->
      <div class="chain-settings-card" id="beer-chain-card">
        <div class="chain-settings-header">
          <div class="chain-settings-icon">🍺</div>
          <div class="chain-settings-info">
            <span class="chain-settings-title">Пиво</span>
            <span class="chain-settings-subtitle">Закуски к пиву</span>
          </div>
          <div class="chain-settings-arrow" id="beer-arrow">›</div>
        </div>
        
        <div class="chain-settings-body" id="beer-chain-body">
          <div class="chain-toggle-item">
            <div class="chain-toggle-info">
              <span class="chain-toggle-label">Картофель фри</span>
              <span class="chain-toggle-desc">Все виды картофеля фри</span>
            </div>
            <div class="settings-toggle ${dishChainSettings.beer?.fries !== false ? 'active' : ''}" data-chain-toggle="beer-fries"></div>
          </div>
          
          <div class="chain-toggle-item">
            <div class="chain-toggle-info">
              <span class="chain-toggle-label">Креветки в кляре</span>
              <span class="chain-toggle-desc">Предложение креветок к пиву</span>
            </div>
            <div class="settings-toggle ${dishChainSettings.beer?.shrimp !== false ? 'active' : ''}" data-chain-toggle="beer-shrimp"></div>
          </div>
          
          <div class="chain-toggle-item">
            <div class="chain-toggle-info">
              <span class="chain-toggle-label">Чесночные гренки</span>
              <span class="chain-toggle-desc">Предложение гренок к пиву</span>
            </div>
            <div class="settings-toggle ${dishChainSettings.beer?.croutons !== false ? 'active' : ''}" data-chain-toggle="beer-croutons"></div>
          </div>
          
          <div class="chain-toggle-item">
            <div class="chain-toggle-info">
              <span class="chain-toggle-label">Креветки пиль-пиль</span>
              <span class="chain-toggle-desc">Предложение креветок пиль-пиль к пиву</span>
            </div>
            <div class="settings-toggle ${dishChainSettings.beer?.pilpil !== false ? 'active' : ''}" data-chain-toggle="beer-pilpil"></div>
          </div>
        </div>
      </div>
    </div>
  `;

  wrapper.appendChild(panel);
  
  // Render custom chains if any
  if (dishChainSettings.custom && Object.keys(dishChainSettings.custom).length > 0) {
    const customSection = document.createElement('div');
    customSection.className = 'settings-section';
    customSection.innerHTML = '<h3 style="margin-bottom: 16px; color: var(--text-primary);">Пользовательские связки</h3>';
    
    const customContainer = document.createElement('div');
    customContainer.className = 'chain-settings-section';
    
    Object.entries(dishChainSettings.custom).forEach(([key, chain]) => {
      const card = document.createElement('div');
      card.className = 'chain-settings-card';
      card.id = `custom-chain-${key}`;
      
      card.innerHTML = `
        <div class="chain-settings-header">
          <div class="chain-settings-icon">🔗</div>
          <div class="chain-settings-info">
            <span class="chain-settings-title">${chain.name}</span>
            <span class="chain-settings-subtitle">${chain.description || 'Пользовательская связка'}</span>
          </div>
          <button class="chain-delete-btn" data-chain-key="${key}" title="Удалить">🗑️</button>
          <div class="chain-settings-arrow">›</div>
        </div>
        
        <div class="chain-settings-body">
          <div class="chain-info-section">
            <div class="chain-info-item">
              <span class="chain-info-label">К чему предлагать:</span>
              <span class="chain-info-value">${chain.triggerDish.name}</span>
            </div>
            <div class="chain-info-item">
              <span class="chain-info-label">Что предлагать:</span>
              <div class="chain-suggested-list">
                ${chain.suggestedDishes.map(d => `
                  <div class="chain-suggested-item">${d.name}${d.isCustom ? ' (свой)' : ''}</div>
                `).join('')}
              </div>
            </div>
          </div>
          
          <div class="chain-toggle-item">
            <div class="chain-toggle-info">
              <span class="chain-toggle-label">Включено</span>
              <span class="chain-toggle-desc">Предлагать эту связку</span>
            </div>
            <div class="settings-toggle ${chain.enabled !== false ? 'active' : ''}" data-custom-toggle="${key}"></div>
          </div>
        </div>
      `;
      
      customContainer.appendChild(card);
    });
    
    customSection.appendChild(customContainer);
    panel.querySelector('.settings-section').after(customSection);
  }

  wrapper.appendChild(panel);

  // Back button
  wrapper.querySelector('#dish-chain-back').addEventListener('click', () => {
    window.location.hash = '#/settings';
  });

  // Create custom chain button
  wrapper.querySelector('#btn-create-custom-chain').addEventListener('click', () => {
    showCreateCustomChainModal();
  });

  // Card expand/collapse handlers
  const cards = [
    { id: 'steak', header: '.chain-settings-header', body: '#steak-chain-body', arrow: '#steak-arrow' },
    { id: 'tea', header: '.chain-settings-header', body: '#tea-chain-body', arrow: '#tea-arrow' },
    { id: 'tartare', header: '.chain-settings-header', body: '#tartare-chain-body', arrow: '#tartare-arrow' },
    { id: 'cocktail', header: '.chain-settings-header', body: '#cocktail-chain-body', arrow: '#cocktail-arrow' },
    { id: 'vitello', header: '.chain-settings-header', body: '#vitello-chain-body', arrow: '#vitello-arrow' },
    { id: 'beer', header: '.chain-settings-header', body: '#beer-chain-body', arrow: '#beer-arrow' }
  ];

  cards.forEach(card => {
    const cardEl = wrapper.querySelector(`#${card.id}-chain-card`);
    if (!cardEl) return;
    
    const headerEl = cardEl.querySelector(card.header);
    const arrowEl = cardEl.querySelector(card.arrow);
    
    headerEl.addEventListener('click', () => {
      cardEl.classList.toggle('expanded');
      arrowEl.textContent = cardEl.classList.contains('expanded') ? '‹' : '›';
    });
  });
  
  // Custom chains expand/collapse
  wrapper.querySelectorAll('[id^="custom-chain-"]').forEach(cardEl => {
    const headerEl = cardEl.querySelector('.chain-settings-header');
    const arrowEl = cardEl.querySelector('.chain-settings-arrow');
    
    headerEl.addEventListener('click', (e) => {
      // Don't toggle if clicking delete button
      if (e.target.classList.contains('chain-delete-btn')) return;
      
      cardEl.classList.toggle('expanded');
      arrowEl.textContent = cardEl.classList.contains('expanded') ? '‹' : '›';
    });
  });
  
  // Delete custom chain handlers
  wrapper.querySelectorAll('.chain-delete-btn').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      const chainKey = btn.dataset.chainKey;
      const chainName = dishChainSettings.custom[chainKey].name;
      
      if (confirm(`Удалить связку "${chainName}"?`)) {
        delete dishChainSettings.custom[chainKey];
        saveDishChainSettings();
        navigate('#/settings/additional-sales');
      }
    });
  });
  
  // Custom chain toggle handlers
  wrapper.querySelectorAll('[data-custom-toggle]').forEach(toggle => {
    const chainKey = toggle.dataset.customToggle;
    
    toggle.addEventListener('click', (e) => {
      e.stopPropagation();
      
      const currentValue = dishChainSettings.custom[chainKey].enabled !== false;
      const nextValue = !currentValue;
      dishChainSettings.custom[chainKey].enabled = nextValue;
      toggle.classList.toggle('active', nextValue);
      
      saveDishChainSettings();
    });
  });

  // Toggle handlers
  wrapper.querySelectorAll('[data-chain-toggle]').forEach(toggle => {
    const key = toggle.dataset.chainToggle;
    
    // Skip cooking - it's always required
    if (key === 'cooking') return;
    
    toggle.addEventListener('click', (e) => {
      e.stopPropagation();
      
      // Parse key: "category-option"
      if (key.includes('-')) {
        const [category, option] = key.split('-');
        
        // Initialize category if not exists
        if (!dishChainSettings[category]) {
          dishChainSettings[category] = {};
        }
        
        const currentValue = dishChainSettings[category][option] !== false;
        const nextValue = !currentValue;
        dishChainSettings[category][option] = nextValue;
        toggle.classList.toggle('active', nextValue);
      } else {
        // Old format for steaks
        const currentValue = dishChainSettings.steaks[key] !== false;
        const nextValue = !currentValue;
        dishChainSettings.steaks[key] = nextValue;
        toggle.classList.toggle('active', nextValue);
      }
      
      saveDishChainSettings();
    });
  });

  return wrapper;
}


// Show modal for creating custom chain
function showCreateCustomChainModal() {
  const modal = document.createElement('div');
  modal.className = 'rename-modal';
  modal.innerHTML = `
    <div class="rename-content custom-chain-modal">
      <div class="rename-title">Создать связку</div>
      
      <div class="custom-chain-form">
        <!-- 1. Название -->
        <div class="form-group">
          <label class="form-label">Название связки</label>
          <input type="text" class="form-input" id="chain-name" placeholder="Например: Кофе с десертом">
        </div>
        
        <!-- 2. Описание -->
        <div class="form-group">
          <label class="form-label">Описание</label>
          <input type="text" class="form-input" id="chain-description" placeholder="Краткое описание">
        </div>
        
        <!-- 3. К чему предлагать -->
        <div class="form-group">
          <label class="form-label">К чему предлагать?</label>
          <div class="selected-dish-container" id="trigger-dish-container">
            <div class="empty-state">Выберите блюдо</div>
          </div>
          <button class="btn-select-dish" id="btn-select-trigger">
            <span class="btn-icon">🔍</span>
            <span>Выбрать блюдо</span>
          </button>
        </div>
        
        <!-- 4. Что предлагать -->
        <div class="form-group">
          <label class="form-label">Что предлагать?</label>
          <div class="selected-dishes-list" id="suggested-dishes-list">
            <div class="empty-state">Добавьте блюда</div>
          </div>
          <div class="button-group">
            <button class="btn-select-dish secondary" id="btn-add-from-menu">
              <span class="btn-icon">📋</span>
              <span>Из меню</span>
            </button>
            <button class="btn-select-dish secondary" id="btn-add-custom">
              <span class="btn-icon">✨</span>
              <span>Свой вариант</span>
            </button>
          </div>
        </div>
      </div>
      
      <div class="rename-actions">
        <button class="chain-skip-btn" id="cancel-chain">Отмена</button>
        <button class="chain-confirm-btn" id="save-chain">Создать</button>
      </div>
    </div>
  `;
  
  document.body.appendChild(modal);
  
  // State
  let triggerDish = null;
  let suggestedDishes = [];
  
  // Select trigger dish
  modal.querySelector('#btn-select-trigger').addEventListener('click', () => {
    showDishSearchModal((dish) => {
      triggerDish = dish;
      updateTriggerDishDisplay();
    });
  });
  
  // Add dish from menu
  modal.querySelector('#btn-add-from-menu').addEventListener('click', () => {
    showDishSearchModal((dish) => {
      // Check if already added
      if (suggestedDishes.find(d => d.rkeeper === dish.R_keeper)) {
        alert('Это блюдо уже добавлено');
        return;
      }
      
      suggestedDishes.push({
        name: dish.name,
        rkeeper: dish.R_keeper,
        price: dish.price,
        isCustom: false
      });
      updateSuggestedDishesDisplay();
    });
  });
  
  // Add custom dish
  modal.querySelector('#btn-add-custom').addEventListener('click', () => {
    showCustomDishModal((customDish) => {
      suggestedDishes.push({
        ...customDish,
        isCustom: true
      });
      updateSuggestedDishesDisplay();
    });
  });
  
  // Update trigger dish display
  function updateTriggerDishDisplay() {
    const container = modal.querySelector('#trigger-dish-container');
    if (triggerDish) {
      container.innerHTML = `
        <div class="selected-dish-item">
          <div class="dish-item-info">
            <span class="dish-item-name">${triggerDish.name}</span>
            <span class="dish-item-code">R_keeper: ${triggerDish.R_keeper}</span>
          </div>
          <button class="dish-item-remove" data-action="remove-trigger">×</button>
        </div>
      `;
      
      container.querySelector('[data-action="remove-trigger"]').addEventListener('click', () => {
        triggerDish = null;
        updateTriggerDishDisplay();
      });
    } else {
      container.innerHTML = '<div class="empty-state">Выберите блюдо</div>';
    }
  }
  
  // Update suggested dishes display
  function updateSuggestedDishesDisplay() {
    const list = modal.querySelector('#suggested-dishes-list');
    if (suggestedDishes.length === 0) {
      list.innerHTML = '<div class="empty-state">Добавьте блюда</div>';
      return;
    }
    
    list.innerHTML = suggestedDishes.map((dish, index) => `
      <div class="selected-dish-item">
        <div class="dish-item-info">
          <span class="dish-item-name">${dish.name}</span>
          <span class="dish-item-code">R_keeper: ${dish.rkeeper}${dish.isCustom ? ' (свой вариант)' : ''}</span>
        </div>
        <button class="dish-item-remove" data-index="${index}">×</button>
      </div>
    `).join('');
    
    // Remove dish handlers
    list.querySelectorAll('.dish-item-remove').forEach(btn => {
      btn.addEventListener('click', () => {
        const index = parseInt(btn.dataset.index);
        suggestedDishes.splice(index, 1);
        updateSuggestedDishesDisplay();
      });
    });
  }
  
  // Cancel
  modal.querySelector('#cancel-chain').addEventListener('click', () => {
    document.body.removeChild(modal);
  });
  
  // Save
  modal.querySelector('#save-chain').addEventListener('click', () => {
    const name = modal.querySelector('#chain-name').value.trim();
    const description = modal.querySelector('#chain-description').value.trim();
    
    // Validation
    if (!name) {
      alert('Введите название связки');
      return;
    }
    
    if (!triggerDish) {
      alert('Выберите блюдо, к которому предлагать');
      return;
    }
    
    if (suggestedDishes.length === 0) {
      alert('Добавьте хотя бы одно блюдо для предложения');
      return;
    }
    
    // Create chain key from name
    const chainKey = name.toLowerCase().replace(/[^a-zа-яё0-9]/g, '_');
    
    // Save to dishChainSettings
    if (!dishChainSettings.custom) {
      dishChainSettings.custom = {};
    }
    
    dishChainSettings.custom[chainKey] = {
      name: name,
      description: description,
      triggerDish: {
        name: triggerDish.name,
        rkeeper: triggerDish.R_keeper
      },
      suggestedDishes: suggestedDishes,
      enabled: true
    };
    
    saveDishChainSettings();
    
    // Close modal and refresh view
    document.body.removeChild(modal);
    alert('Связка создана!');
    
    // Refresh the page to show new chain
    navigate('#/settings/additional-sales');
  });
  
  // Close on outside click
  modal.addEventListener('click', (e) => {
    if (e.target === modal) {
      document.body.removeChild(modal);
    }
  });
}

// Show dish search modal
function showDishSearchModal(onSelect) {
  const modal = document.createElement('div');
  modal.className = 'rename-modal';
  modal.innerHTML = `
    <div class="rename-content dish-search-modal">
      <div class="rename-title">Выбрать блюдо</div>
      
      <div class="search-container" style="margin-bottom: 16px;">
        <input type="text" class="form-input" id="dish-search-input" placeholder="Поиск блюда...">
      </div>
      
      <div class="dish-search-results" id="dish-search-results">
        <div class="empty-state">Начните вводить название блюда</div>
      </div>
      
      <button class="chain-skip-btn" id="cancel-search">Отмена</button>
    </div>
  `;
  
  document.body.appendChild(modal);
  
  const searchInput = modal.querySelector('#dish-search-input');
  const resultsContainer = modal.querySelector('#dish-search-results');
  
  // Search handler
  searchInput.addEventListener('input', async () => {
    const query = searchInput.value.trim().toLowerCase();
    
    if (query.length < 2) {
      resultsContainer.innerHTML = '<div class="empty-state">Введите минимум 2 символа</div>';
      return;
    }
    
    // Load database if not loaded
    if (!db || !db.dishes || db.dishes.length === 0) {
      console.log('Loading database...');
      try {
        await loadDb();
      } catch (error) {
        console.error('Error loading database:', error);
      }
    }
    
    // Check if db is loaded
    if (!db || !db.dishes || db.dishes.length === 0) {
      console.error('Database not loaded! db:', db);
      resultsContainer.innerHTML = '<div class="empty-state">Ошибка загрузки базы данных</div>';
      return;
    }
    
    // Search in dishes
    const results = db.dishes.filter(dish => 
      dish.name.toLowerCase().includes(query)
    ).slice(0, 20); // Limit to 20 results
    
    if (results.length === 0) {
      resultsContainer.innerHTML = '<div class="empty-state">Ничего не найдено</div>';
      return;
    }
    
    resultsContainer.innerHTML = results.map(dish => `
      <div class="dish-search-item" data-rkeeper="${dish.R_keeper}">
        <div class="dish-search-info">
          <span class="dish-search-name">${dish.name}</span>
          <span class="dish-search-category">${dish.category}</span>
        </div>
        <span class="dish-search-price">${dish.price}</span>
      </div>
    `).join('');
    
    // Click handlers
    resultsContainer.querySelectorAll('.dish-search-item').forEach(item => {
      item.addEventListener('click', () => {
        const rkeeper = item.dataset.rkeeper;
        const dish = db.dishes.find(d => d.R_keeper === rkeeper);
        if (dish) {
          onSelect(dish);
          document.body.removeChild(modal);
        }
      });
    });
  });
  
  // Cancel
  modal.querySelector('#cancel-search').addEventListener('click', () => {
    document.body.removeChild(modal);
  });
  
  // Close on outside click
  modal.addEventListener('click', (e) => {
    if (e.target === modal) {
      document.body.removeChild(modal);
    }
  });
  
  // Focus search input
  setTimeout(() => searchInput.focus(), 100);
}

// Show custom dish modal
function showCustomDishModal(onSave) {
  const modal = document.createElement('div');
  modal.className = 'rename-modal';
  modal.innerHTML = `
    <div class="rename-content custom-dish-modal">
      <div class="rename-title">Свой вариант</div>
      
      <div class="custom-dish-form">
        <div class="form-group">
          <label class="form-label">Название</label>
          <input type="text" class="form-input" id="custom-dish-name" placeholder="Например: Мята">
        </div>
        
        <div class="form-group">
          <label class="form-label">Описание</label>
          <input type="text" class="form-input" id="custom-dish-description" placeholder="Например: Трава для чая">
        </div>
        
        <div class="form-group">
          <label class="form-label">Код R_keeper</label>
          <input type="text" class="form-input" id="custom-dish-rkeeper" placeholder="Например: 343">
        </div>
        
        <div class="form-group">
          <label class="form-label">Цена (необязательно)</label>
          <input type="text" class="form-input" id="custom-dish-price" placeholder="Например: 50 рублей">
        </div>
      </div>
      
      <div class="rename-actions">
        <button class="chain-skip-btn" id="cancel-custom">Отмена</button>
        <button class="chain-confirm-btn" id="save-custom">Добавить</button>
      </div>
    </div>
  `;
  
  document.body.appendChild(modal);
  
  // Save
  modal.querySelector('#save-custom').addEventListener('click', () => {
    const name = modal.querySelector('#custom-dish-name').value.trim();
    const description = modal.querySelector('#custom-dish-description').value.trim();
    const rkeeper = modal.querySelector('#custom-dish-rkeeper').value.trim();
    const price = modal.querySelector('#custom-dish-price').value.trim();
    
    // Validation
    if (!name) {
      alert('Введите название');
      return;
    }
    
    if (!rkeeper) {
      alert('Введите код R_keeper');
      return;
    }
    
    onSave({
      name: name,
      description: description,
      rkeeper: rkeeper,
      price: price || '—'
    });
    
    document.body.removeChild(modal);
  });
  
  // Cancel
  modal.querySelector('#cancel-custom').addEventListener('click', () => {
    document.body.removeChild(modal);
  });
  
  // Close on outside click
  modal.addEventListener('click', (e) => {
    if (e.target === modal) {
      document.body.removeChild(modal);
    }
  });
  
  // Focus first input
  setTimeout(() => modal.querySelector('#custom-dish-name').focus(), 100);
}

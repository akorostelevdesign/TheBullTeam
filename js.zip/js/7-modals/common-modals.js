/* Common Modals - Общие модальные окна */
/* Версия: 1.63.0 */

// Rename table modal
function showRenameTableModal(tableNumber) {
  const modal = document.createElement('div');
  modal.className = 'rename-modal';
  modal.innerHTML = `
    <div class="rename-content">
      <div class="rename-title">Переименовать стол</div>
      <input type="text" class="rename-input" id="rename-input" value="${getTableDisplayName(tableNumber)}" placeholder="Введите название стола">
      <div class="rename-actions">
        <button class="btn secondary" id="rename-cancel">Отмена</button>
        <button class="btn primary" id="rename-save">Сохранить</button>
      </div>
    </div>
  `;
  
  document.body.appendChild(modal);
  
  const input = modal.querySelector('#rename-input');
  const cancelBtn = modal.querySelector('#rename-cancel');
  const saveBtn = modal.querySelector('#rename-save');
  
  // Focus and select text
  input.focus();
  input.select();
  
  // Event handlers
  cancelBtn.addEventListener('click', () => {
    document.body.removeChild(modal);
  });
  
  saveBtn.addEventListener('click', () => {
    const newName = input.value.trim();
    if (newName) {
      tableNames[tableNumber] = newName;
      saveTableNames();
      render(); // Re-render to update all table names
    }
    document.body.removeChild(modal);
  });
  
  // Close on Enter key
  input.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      saveBtn.click();
    }
  });
  
  // Close on Escape key
  input.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      cancelBtn.click();
    }
  });
  
  // Close on outside click
  modal.addEventListener('click', (e) => {
    if (e.target === modal) {
      cancelBtn.click();
    }
  });
}

// Confirmation modal
function showConfirmModal(title, message, onConfirm, onCancel, confirmButtonText = 'Удалить') {
  const modal = document.createElement('div');
  modal.className = 'confirm-modal';
  modal.innerHTML = `
    <div class="confirm-content">
      <div class="confirm-title">${title}</div>
      <div class="confirm-message">${message}</div>
      <div class="confirm-actions">
        <button class="btn secondary" id="confirm-cancel">Отмена</button>
        <button class="btn danger" id="confirm-ok">${confirmButtonText}</button>
      </div>
    </div>
  `;
  
  document.body.appendChild(modal);
  
  modal.querySelector('#confirm-cancel').addEventListener('click', () => {
    document.body.removeChild(modal);
    if (onCancel) onCancel();
  });
  
  modal.querySelector('#confirm-ok').addEventListener('click', () => {
    document.body.removeChild(modal);
    if (onConfirm) onConfirm();
  });
}

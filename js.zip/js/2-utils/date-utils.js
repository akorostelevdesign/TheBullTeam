/* Date Utility Functions - Функции для работы с датами */
/* Версия: 1.63.0 */

// Очистка старой истории заказов (старше указанного количества дней)
function ensureMonthlyPurge(daysToKeep = 31) {
  const now = new Date();
  const monthKey = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
  if (meta.lastPurgeMonth === monthKey) return;

  const cutoff = now.getTime() - daysToKeep * 24 * 60 * 60 * 1000;
  orderHistory = (orderHistory || []).filter(h => {
    const closedAt = typeof h?.closedAt === 'number' ? h.closedAt : 0;
    return closedAt >= cutoff;
  });
  meta.lastPurgeMonth = monthKey;
  saveOrderHistory();
  saveMeta();
}

// Автоматическая очистка столов в 23:50 и удаление истории в 23:55 МСК
function scheduleDailyCleanup() {
  function checkAndCleanup() {
    // Get current time in MSK (UTC+3)
    const now = new Date();
    const mskOffset = 3 * 60; // MSK is UTC+3
    const localOffset = now.getTimezoneOffset(); // minutes from UTC
    const mskTime = new Date(now.getTime() + (mskOffset + localOffset) * 60 * 1000);
    
    const hours = mskTime.getHours();
    const minutes = mskTime.getMinutes();
    const dateKey = mskTime.toISOString().split('T')[0]; // YYYY-MM-DD
    
    // Очистка столов в 23:50 МСК
    if (hours === 23 && minutes === 50) {
      const lastCleanup = localStorage.getItem('waiter.lastDailyCleanup');
      
      if (lastCleanup !== dateKey) {
        console.log('🧹 Автоматическая очистка столов в 23:50 МСК');
        
        // Сохраняем все заказы в историю перед очисткой
        activeTables.forEach(tableNum => {
          const items = tableOrders[tableNum] || [];
          if (items.length === 0) return;
          
          const total = computeTableTotalAmount(tableNum);
          const displayName = tableNames[tableNum] || `Стол ${tableNum}`;
          
          orderHistory.push({
            table: tableNum,
            tableName: displayName,
            items: items.map(i => ({ itemName: i.itemName, quantity: i.quantity, price: i.price })),
            total: total,
            createdAt: items[0]?.createdAt || Date.now(),
            closedAt: Date.now()
          });
        });
        
        // Очищаем все столы
        tableOrders = {};
        activeTables = [];
        tableNames = {};
        
        // Сохраняем изменения
        saveTableOrders();
        saveTables();
        saveTableNames();
        saveOrderHistory();
        
        // Отмечаем, что очистка выполнена сегодня
        localStorage.setItem('waiter.lastDailyCleanup', dateKey);
        
        // Обновляем UI если на странице столов
        if (currentPage === 'tables') {
          render();
        }
        
        console.log('✅ Все столы очищены и перенесены в историю');
      }
    }
    
    // Удаление истории в 23:55 МСК
    if (hours === 23 && minutes === 55) {
      const lastHistoryDelete = localStorage.getItem('waiter.lastHistoryDelete');
      
      if (lastHistoryDelete !== dateKey) {
        console.log('🗑️ Автоматическое удаление истории заказов в 23:55 МСК');
        
        // Очищаем историю заказов
        orderHistory = [];
        saveOrderHistory();
        
        // Отмечаем, что удаление выполнено сегодня
        localStorage.setItem('waiter.lastHistoryDelete', dateKey);
        
        // Обновляем UI если на странице истории
        if (currentPage === 'order-history') {
          render();
        }
        
        console.log('✅ История заказов удалена');
      }
    }
  }
  
  // Проверяем каждую минуту
  setInterval(checkAndCleanup, 60 * 1000);
  
  // Проверяем сразу при загрузке
  checkAndCleanup();
}

// Подсчёт метрик за месяц (выручка, чаевые)
function computeMonthlyMetrics(targetDate = new Date()) {
  const monthKey = `${targetDate.getFullYear()}-${String(targetDate.getMonth() + 1).padStart(2, '0')}`;
  const isSameMonth = (ts) => {
    const d = new Date(ts);
    return d.getFullYear() === targetDate.getFullYear() && d.getMonth() === targetDate.getMonth();
  };

  const monthHistory = (orderHistory || []).filter(h => isSameMonth(h.closedAt));
  const revenue = monthHistory.reduce((sum, h) => sum + (h.total || 0), 0);
  const tips = monthHistory.reduce((sum, h) => sum + (h.tips || 0), 0);
  const tablesCount = monthHistory.length;

  return { revenue, tips, tablesCount, monthKey };
}
